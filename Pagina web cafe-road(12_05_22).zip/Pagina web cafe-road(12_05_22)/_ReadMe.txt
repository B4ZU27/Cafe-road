- Para crear la base de datos que se va a usar primero correr creardb desde el localhost en el explorador web (espero que para cuando leas esto ya lo haya explicado). Solo se crea una vez asi que si ya la tienes con eso basta

- Procesos_controlador y procesos_vista son mis trabajos, puedes usarlos para crear las tablas tambien desde el localhost de php. No hagas cambios ahí o podria fallar, para agregar tu parte tendras que hacer tu propio controlador y vista de la pagina que te toco

- Pruebas solo lo use como su nombre dice para hacer pruebas, si quieres usalo, solo tienes que cambiar en la vista a donde redirecciona el action, si tienes dudas de como usarlo mejor ni lo uses

- Asegurate de que esta carpeta este en .../xampp/htdocs, si no nada va a funcionar
<?php
    $host = "localhost";
    $user = "id18818891_root";
    $pass = "@proyectoEquipo2";
    $db = "id18818891_caferoad";

    $conn = mysqli_connect($host, $user, $pass, $db) or die("Connection Failed" .mysqli_connect_error());

?>
(function(){
    console.log("Js started");
})()